<?php
$number = $_POST['no'];
$con = new mysqli("localhost","root","","electronic");
$s = "select * from delivery_person_details where d_id=$number";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num == 0){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Invalid Delivery person ID!")';  
    echo '</script>'; 
}else{
$reg = "delete from delivery_person_details where d_id=$number ";
    if(mysqli_query($con, $reg))
    {

    
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Account deleted Successfully")';  
    echo '</script>'; 
    }else{
        echo '<script type ="text/JavaScript">';  
    echo 'alert("Account deletion Failed")';  
    echo '</script>'; 
    }
}
?>
<meta http-equiv="refresh" content="0;url=removeemp.html"/>