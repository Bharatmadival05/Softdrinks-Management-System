<?php
session_start();
$id=$_SESSION['CUST_ID'];
$branch = $_POST['branch'];
$msg = $_POST['msg'];
$con = new mysqli("localhost","root","123456789","electronic");
$insert = "INSERT INTO getintouch(CUST_ID,PLACE,MSG) VALUES($id,'$branch','$msg')";
 if(mysqli_query($con, $insert)){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Message Sent Successfully")';  
    echo '</script>'; 
 }else{
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Message Sending Failed")';  
    echo '</script>'; 
 }
?>
<meta http-equiv="refresh" content="0;url=homepage.html"/>