<?php
session_start();
$id=$_SESSION['CUST_ID'];
$name = $_POST['name'];
$quantity = $_POST['q'];
$con = new mysqli("localhost","root","","electronic");
if($id == null){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Login Again !")';  
    echo '</script>'; 
}else{

$s = "select * from product where PRODUCT_NAME = '$name'";
$result = mysqli_query($con, $s);
$row = mysqli_fetch_assoc($result);
$cost = $row['COST'];
$quantity1 = $row['QUANTITY'];
if($quantity1<$quantity){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("We have Low Stock !")';  
    echo '</script>'; 
}else{
 $totcost=$cost*$quantity;
 $insert = "INSERT INTO ORDERS(CUST_ID,PRODUCT_NAME,QUANTITY,AMOUNT) VALUES($id,'$name',$quantity,$totcost)";
 if(mysqli_query($con, $insert)){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Order Done! Product will be Deivered Soon")';  
    echo '</script>'; 
 }else{
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Ordering Failed")';  
    echo '</script>'; 
 }



}
}
?>
<meta http-equiv="refresh" content="0;url=makeorder.html"/>