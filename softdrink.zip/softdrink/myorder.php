<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My-Orders</title>
    <link rel="icon" href="logo.png" type="image/icon type">
    <style type="text/css">
        table {
            border-collapse: collapse;
            width: 100%;
            color: rgb(76, 15, 247);
            font-family: monospace;
            font-size: 25px;
            text-align: left;
        }
        th {
            background-color: rgb(76, 15, 247);
            color: white; 
        }
        tr:nth-child(even) {background-color: rgb(144, 144, 243)}
    </style>
</head>
<body>
    <table>
        <tr>
            <th>ORDER_ID</th>
            <th>PRODUCT_NAME</th>
            <th>QUANTITY</th>
            <th>AMOUNT</th>
            <th>Status</th>
        </tr>
        <?php
        session_start();
        $id=$_SESSION['CUST_ID'];
       $con = new mysqli("localhost","root","","electronic");
        $sql = "SELECT * FROM orders where CUST_ID=$id";
        $result = $con-> query($sql);
        if($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()) {
                echo "<tr><td>".$row["ORDER_NO"]."</td><td>".$row["PRODUCT_NAME"]."</td><td>".$row["QUANTITY"]."</td><td>".$row["AMOUNT"]."</td><td>".$row["STATUS"]."</td></tr>";
            }
            echo "</table>";
        }
        $con-> close();
        ?>
    </table>
</body>
</html>