<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Customer</title>
    <link rel="icon" href="logo.png" type="image/icon type">
    <style type="text/css">
        table {
            border-collapse: collapse;
            width: 100%;
            color: rgb(76, 15, 247);
            font-family: monospace;
            font-size: 25px;
            text-align: left;
        }
        th {
            background-color: rgb(76, 15, 247);
            color: white; 
        }
        tr:nth-child(even) {background-color: rgb(144, 144, 243)}
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Customer_ID</th>
            <th>Name</th>
            <th>MOBILE</th>
            <th>BRANCH</th>
            
            
        </tr>
        <?php
       $con = new mysqli("localhost","root","123456789","electronic");

       $sql1="SELECT * FROM `cust_count`";
       $result1=mysqli_query($con,$sql1);
       $row1 = mysqli_fetch_assoc($result1);
       
       ?>
       <h1 style="color:  #ff7200 ;">TOTAL CUSTOMER IS:<?php echo $row1['total_number'];?>
       <?php





        $sql = "select * from customer_details natural join branch_details";
        $result = $con-> query($sql);
        if($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()) {
                echo "<tr><td>".$row["CUST_ID"]."</td><td>".$row["NAME"]."</td><td>".$row["PHONE"]."</td><td>".$row["b_name"]."</td></tr>";
            }
            echo "</table>";
        }
        $con-> close();
    
        ?>
        
    </table>
</body>
</html>