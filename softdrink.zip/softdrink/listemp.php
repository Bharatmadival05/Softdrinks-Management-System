<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery-Guys</title>
    <link rel="icon" href="logo.png" type="image/icon type">
    <style type="text/css">
        table {
            border-collapse: collapse;
            width: 100%;
            color: rgb(76, 15, 247);
            font-family: monospace;
            font-size: 25px;
            text-align: left;
        }
        th {
            background-color: rgb(76, 15, 247);
            color: white; 
        }
        tr:nth-child(even) {background-color: rgb(144, 144, 243)}
    </style>
</head>
<body>
    <table>
        <tr>
            <th>EMP_ID</th>
            <th>NAME</th>
            <th>NUMBER</th>
            <th>BRANCH</th>
           
        </tr>
        <?php
       $con = new mysqli("localhost","root","","electronic");
        $sql = "SELECT * FROM delivery_person_details natural join branch_details ";
        $result = $con-> query($sql);
        if($result-> num_rows > 0){
            while($row = $result-> fetch_assoc()) {
                echo "<tr><td>".$row["d_id"]."</td><td>".$row["name"]."</td><td>".$row["number"]."</td><td>".$row["b_name"]."</td></tr>";
            }
            echo "</table>";
        }
        $con-> close();
    
        ?>
        
    </table>
</body>
</html>