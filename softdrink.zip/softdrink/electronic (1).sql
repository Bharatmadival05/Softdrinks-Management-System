-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 21, 2023 at 02:01 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `electronic`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `proc`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc` (IN `name` VARCHAR(20), IN `pass` VARCHAR(20))  NO SQL
INSERT INTO admin_details VALUES(name,pass)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

DROP TABLE IF EXISTS `admin_details`;
CREATE TABLE IF NOT EXISTS `admin_details` (
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`name`, `password`) VALUES
('mehboob', 'mehboob'),
('sneha', 'sneha'),
('jj', 'jj');

-- --------------------------------------------------------

--
-- Table structure for table `branch_details`
--

DROP TABLE IF EXISTS `branch_details`;
CREATE TABLE IF NOT EXISTS `branch_details` (
  `b_id` int(11) NOT NULL,
  `b_name` varchar(30) NOT NULL,
  PRIMARY KEY (`b_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch_details`
--

INSERT INTO `branch_details` (`b_id`, `b_name`) VALUES
(1, 'Manglore'),
(2, 'Kundapura'),
(3, 'Udupi'),
(4, 'Karkala');

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

DROP TABLE IF EXISTS `customer_details`;
CREATE TABLE IF NOT EXISTS `customer_details` (
  `CUST_ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(25) NOT NULL,
  `EMAIL` varchar(30) NOT NULL,
  `PASSWORD` varchar(30) NOT NULL,
  `PHONE` varchar(15) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `b_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`CUST_ID`),
  KEY `b_id` (`b_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`CUST_ID`, `NAME`, `EMAIL`, `PASSWORD`, `PHONE`, `ADDRESS`, `b_id`) VALUES
(6, 'hey', 'mehboob@email.com', 'anam', '88', '77', 1),
(5, 'padmavati.....', 'padma@gmail.com', '555', '55', 'ii', 1),
(4, 'Mehboob khan', 'mehbob@email.com', '123456', '7', 'aaaa', 1);

--
-- Triggers `customer_details`
--
DROP TRIGGER IF EXISTS `trig`;
DELIMITER $$
CREATE TRIGGER `trig` AFTER INSERT ON `customer_details` FOR EACH ROW UPDATE cust_count set total_number=total_number+1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cust_count`
--

DROP TABLE IF EXISTS `cust_count`;
CREATE TABLE IF NOT EXISTS `cust_count` (
  `total_number` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cust_count`
--

INSERT INTO `cust_count` (`total_number`) VALUES
(3);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_person_details`
--

DROP TABLE IF EXISTS `delivery_person_details`;
CREATE TABLE IF NOT EXISTS `delivery_person_details` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `number` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `b_id` int(11) NOT NULL,
  `address` varchar(225) NOT NULL,
  PRIMARY KEY (`d_id`),
  KEY `b_id` (`b_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_person_details`
--

INSERT INTO `delivery_person_details` (`d_id`, `name`, `number`, `password`, `b_id`, `address`) VALUES
(2, 'harish', '897456', '123456', 2, ''),
(3, 'manish', '456789', '12345', 3, ''),
(4, 'mubarak', '897456', '123456', 4, ''),
(5, 'ragu', '11', '11', 1, ''),
(6, 'vidhya', '123', 'vidhya', 2, 'aaaa');

-- --------------------------------------------------------

--
-- Table structure for table `getintouch`
--

DROP TABLE IF EXISTS `getintouch`;
CREATE TABLE IF NOT EXISTS `getintouch` (
  `CUST_ID` int(11) NOT NULL,
  `PLACE` varchar(20) NOT NULL,
  `MSG` text NOT NULL,
  `STATUS` varchar(20) NOT NULL DEFAULT 'Not-Solved',
  KEY `CUST_ID` (`CUST_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getintouch`
--

INSERT INTO `getintouch` (`CUST_ID`, `PLACE`, `MSG`, `STATUS`) VALUES
(2, 'Manglore', 'Hiii', 'Not-Solved'),
(5, 'Manglore', 'hiii', 'Not-Solved');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `ORDER_NO` int(11) NOT NULL AUTO_INCREMENT,
  `CUST_ID` int(11) DEFAULT NULL,
  `PRODUCT_NAME` varchar(20) DEFAULT NULL,
  `QUANTITY` int(11) DEFAULT NULL,
  `AMOUNT` decimal(10,0) DEFAULT NULL,
  `STATUS` varchar(30) DEFAULT 'Not-Delivered',
  `ORDER_TIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `DELIVERY_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ORDER_NO`),
  KEY `PRODUCT_NAME` (`PRODUCT_NAME`),
  KEY `CUST_ID` (`CUST_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ORDER_NO`, `CUST_ID`, `PRODUCT_NAME`, `QUANTITY`, `AMOUNT`, `STATUS`, `ORDER_TIME`, `DELIVERY_TIME`) VALUES
(1, 2, 'REFRIDGERATOR', 1, '80000', 'Delivered', '2022-03-12 20:28:37', '2022-03-16 20:40:00'),
(2, 2, 'REFRIDGERATOR', 1, '80000', 'Delivered', '2022-03-12 20:29:22', '2022-03-05 20:35:00'),
(3, 2, 'IPHONE 12', 1, '80000', 'Delivered', '2022-03-16 18:16:36', '2022-03-05 20:35:00'),
(4, 4, 'IPHONE 12', 2, '160000', 'CANCELLED', '2022-03-16 20:05:12', '2022-03-16 23:39:00'),
(5, 5, 'WATER PURIFIER', 1, '21000', 'CANCELLED', '2022-03-17 15:35:58', NULL),
(6, 5, 'LENOVA 15 5000', 5, '275000', 'Delivered', '2022-03-17 15:42:41', '2022-03-17 15:46:00'),
(7, 5, 'REFRIDGERATOR', 1, '80000', 'Not-Delivered', '2022-03-17 15:48:50', NULL),
(8, 5, 'REFRIDGERATOR', 7, '560000', 'Not-Delivered', '2022-11-15 19:08:13', NULL),
(9, 5, 'REFRIDGERATOR', 1, '80000', 'Not-Delivered', '2022-11-15 19:12:18', NULL),
(10, 5, 'MONITOR HD', 5, '25000', 'CANCELLED', '2023-01-21 19:20:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `PRODUCT_NAME` varchar(20) NOT NULL,
  `COST` decimal(10,0) DEFAULT NULL,
  `COMPANY` varchar(20) DEFAULT NULL,
  `PRODUCT_NO` int(11) NOT NULL AUTO_INCREMENT,
  `QUANTITY` int(11) NOT NULL,
  PRIMARY KEY (`PRODUCT_NAME`),
  UNIQUE KEY `PRODUCT_NO` (`PRODUCT_NO`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`PRODUCT_NAME`, `COST`, `COMPANY`, `PRODUCT_NO`, `QUANTITY`) VALUES
('REFRIDGERATOR', '80000', 'PHILIPS', 1, 15),
('IPHONE 12', '80000', 'APPLE', 2, 20),
('LENOVA 15 5000', '55000', 'LENOVA', 3, 20),
('BOAT V2', '800', 'BOAT', 4, 60),
('AIR-FRIER', '15000', 'PHILIPS', 5, 20),
('WATER BOILER', '5000', 'ASUS', 6, 70),
('WATER PURIFIER', '21000', 'DELLA', 7, 20),
('SPORTS WATCH', '5000', 'LENOVA', 8, 17),
('DIGITAL WATCH', '15000', 'HONOR', 9, 20),
('MONITOR HD', '5000', 'DELLA', 10, 55),
('VIVO Y65', '15000', 'VIVO', 11, 20);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
