<?php

$email = $_POST['email'];
$password = $_POST['pass'];

$con = new mysqli("localhost", "root", "", "electronic");
if ($con->connect_error) {
   die("Failed to connect : " . $con->connect_error);
} else {
   $s = "select * from admin_details where name = '$email' && password = '$password'";
   $result = mysqli_query($con, $s);
   $num = mysqli_num_rows($result);
   if ($num == 1) {


      header("Location:admindashboard.html");
   } else {
      echo '<script type ="text/JavaScript">';
      echo 'alert("Incorrect Credentials!")';
      echo '</script>';
   }

}

?>

<meta http-equiv="refresh" content="0;url=adminlogin.html" />