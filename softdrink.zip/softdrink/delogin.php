<?php

 $email = $_POST['email'];
 $password = $_POST['pass'];
 
 $con = new mysqli("localhost","root","","electronic");
 if($con->connect_error){
    die("Failed to connect : ".$con->connect_error);
 } else{
     $s = "select * from delivery_person_details where d_id = $email && password = '$password'";
     $result = mysqli_query($con, $s);
     $num = mysqli_num_rows($result);
     if($num == 1){
        
        echo '<script type ="text/JavaScript">';  
        echo 'alert("Login Successfull !")';  
        echo '</script>'; 

        header('location:deliverydashboard.html');
         } else {
            echo '<script type ="text/JavaScript">';  
        echo 'alert("Incorrect id or Password!")';  
        echo '</script>';
         }
         session_start();
        $row = mysqli_fetch_assoc($result);
        $_SESSION['b_id']=$row['b_id'];   
     }
    
?>

<meta http-equiv="refresh" content="0;url=delogin.html"/>