<?php
$pass = $_POST['pass'];
$name = $_POST['name'];
$address = $_POST['add'];
$number = $_POST['no'];
$email = $_POST['email'];
$branch = $_POST['branch'];
$con = new mysqli("localhost","root","","electronic");

$reg = "INSERT INTO `customer_details`(NAME,EMAIL,PASSWORD,PHONE,ADDRESS,b_id) VALUES('$name', '$email', '$pass',$number, '$address',$branch)";
    if(mysqli_query($con, $reg))
    {

    
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Account Created Successfully")';  
    echo '</script>'; 
    }else{
        echo '<script type ="text/JavaScript">';  
    echo 'alert("Account Creation Failed")';  
    echo '</script>'; 
    }

?>
<meta http-equiv="refresh" content="0;url=signup.html"/>