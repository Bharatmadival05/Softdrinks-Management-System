<?php
$pass = $_POST['pass'];
$name = $_POST['name'];
$address = $_POST['add'];
$number = $_POST['no'];

$branch = $_POST['branch'];
$con = new mysqli("localhost","root","123456789","electronic");

$reg = "INSERT INTO `delivery_person_details`(name,number,password,b_id,address) VALUES('$name',$number,'$pass',$branch,'$address')";
    if(mysqli_query($con, $reg))
    {

    
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Added Successfully")';  
    echo '</script>'; 
    }else{
        echo '<script type ="text/JavaScript">';  
    echo 'alert("Failed")';  
    echo '</script>'; 
    }

?>
<meta http-equiv="refresh" content="0;url=addemp.html"/>