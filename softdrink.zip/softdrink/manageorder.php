<?php
session_start();
$id=$_SESSION['b_id'];
$name = $_POST['id'];
$tym = $_POST['tym'];
$con = new mysqli("localhost","root","","electronic");
if($id == null){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Login Again !")';  
    echo '</script>'; 
}else{

$s = "select * from orders where ORDER_NO = $name";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num == 0){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Invalid Order ID !")';  
    echo '</script>'; 


}
   else{
 $update = "UPDATE orders SET STATUS='Delivered',DELIVERY_TIME='$tym' where ORDER_NO=$name";
 if(mysqli_query($con, $update)){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Status Updated")';  
    echo '</script>'; 
 }else{
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Updation Failed")';  
    echo '</script>'; 
 }



}
}
?>
<meta http-equiv="refresh" content="0;url=manageorder.html"/>