<?php
$id=$_POST['no'];
$con = new mysqli("localhost","root","","electronic");
$s = "select * from ORDERS where ORDER_NO = $id";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num == 0){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Invalid Order ID!")';  
    echo '</script>'; 
}else{
$STATUS='CANCELLED';
$insert = "update ORDERS SET STATUS='$STATUS' WHERE ORDER_NO=$id";
if(mysqli_query($con, $insert)){
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Operation Completed !")';  
    echo '</script>'; 
 }else{
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Operation Not Completed !")';  
    echo '</script>'; 
 }




}
?>
<meta http-equiv="refresh" content="0;url=cancelorder.html"/>