<?php
$g = $_POST['name'];
$p = $_POST['pass'];
$con = new mysqli("localhost","root","","electronic");

$s = "select * from admin_details where name ='$g' && password='$p'";

$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num > 0){
     echo '<script type ="text/JavaScript">';  
     echo 'alert("User Exists")';  
     echo '</script>'; 
}else{
    $reg = "CALL proc('$g','$p')";
    if(mysqli_query($con, $reg)){
        echo '<script type ="text/JavaScript">';  
        echo 'alert("Updated Successfully")';  
        echo '</script>'; 
      }else{
      echo '<script type ="text/JavaScript">';  
      echo 'alert("Not updated Successfully")';  
      echo '</script>'; 
      }

}
?>
<meta http-equiv="refresh" content="0;url=sharedashboard.html"/>