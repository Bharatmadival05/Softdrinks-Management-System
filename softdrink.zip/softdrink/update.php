<?php
session_start();
$id=$_SESSION['CUST_ID'];
$cpass = $_POST['cpass'];
$npass = $_POST['npass'];
$name = $_POST['name'];
$address = $_POST['add'];
$number = $_POST['no'];
$email = $_POST['email'];
if($id == NULL){
    echo '<script type ="text/JavaScript">';  
        echo 'alert("Login Again")';  
        echo '</script>';  
 }else{

$con = new mysqli("localhost","root","","electronic");
$s = "select * from customer_details where CUST_ID = $id && PASSWORD = '$cpass'";
     $result = mysqli_query($con, $s);
     $num = mysqli_num_rows($result);
     if($num == 0){
        echo '<script type ="text/JavaScript">';  
        echo 'alert("Enter Current Password Correctly!")';  
        echo '</script>'; 

}else{
$reg = "update`customer_details`SET NAME='$name',EMAIL='$email',PASSWORD='$npass',PHONE=$number, ADDRESS='$address' WHERE CUST_ID=$id";
    if(mysqli_query($con, $reg))
    {

    
    echo '<script type ="text/JavaScript">';  
    echo 'alert("Account Updated Successfully")';  
    echo '</script>'; 
    }else{
        echo '<script type ="text/JavaScript">';  
    echo 'alert("Account Updation Failed")';  
    echo '</script>'; 
    }
}
 }
?>
<meta http-equiv="refresh" content="0;url=update.html"/>